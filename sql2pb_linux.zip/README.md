本项目是forked Mikaelemmmm大佬的
个人感觉 命令行太麻烦了 就替换成配置文件的处理方式
原项目地址 github.com/Mikaelemmmm/sql2pb

